var f_flag=0;
var l_flag=0;
var e_flag=0;
var p_flag=0;
var a_flag=0;
var com_flag=0;
var city_flag=0;
var s_flag=0;
var z_flag=0;
var radio_flag=0;
var source_flag=0;
var b_flag=0;




function fname()
{

	var fname = document.getElementById("firstName").value;
	var fnamecheck = /^[A-Za-z.]{3,10}$/ ;
	if (fnamecheck.test(fname)){
        document.getElementById('fname_formerror').innerHTML = "";
		f_flag=0;
	}else{
        document.getElementById('fname_formerror').innerHTML = "*invalid";
		f_flag=1;
	}


}

function lname()
{
	var lname = document.getElementById("lastName").value;
	var lnamecheck = /^[A-Za-z.]{3,10}$/ ;
	if (lnamecheck.test(lname)){
		document.getElementById('lname_formerror').innerHTML = "";
		l_flag=0;
	}else{
		document.getElementById('lname_formerror').innerHTML = "*invalid";
		l_flag=1;
	}

}



function email()
{
	var email = document.getElementById('emailId').value;
	var emailcheck = /^[A-Za-z0-9]+@northeastern\.edu$/;
	if (emailcheck.test(email)){
		document.getElementById('email_formerror').innerHTML = "";
		e_flag=0;
	}else{
		document.getElementById('email_formerror').innerHTML = "*invalid";
		e_flag=1;
	}

}



function phonenumber()
{
	var phonenumber = document.getElementById('phoneNumber').value;
	var phonecheck = /^[0-9]{10}$/;
	if (phonecheck.test(phonenumber)){
		document.getElementById('phone_formerror').innerHTML = "";
		p_flag=0;
	}else{
		document.getElementById('phone_formerror').innerHTML = "*invalid";
		p_flag=1;
	}
	
}

function address()
{
	var st1= document.getElementById('streetAddress1').value;
	var address1 = document.getElementById('streetAddress1').value;
	if (address1.length < 10)
	{
		document.getElementById('st1_formerror').innerHTML = "*invalid";
		a_flag=1;
	    
	}
	else{
		document.getElementById('st1_formerror').innerHTML = "";
		a_flag=0;

	}
}

function comment_1()
{
	
	var ct1 = document.getElementById('comments').value;
	if (ct1.length < 10)
	{
		document.getElementById('comment_formerror').innerHTML = "*invalid";
		com_flag=1;
	    
	}
	else{
		document.getElementById('comment_formerror').innerHTML = "";
		com_flag=0;

	}
}



function city_1()
{
	var city1= document.getElementById('citys').value;
	
	if (city1.length < 5)
	{
		
		document.getElementById('city_formerror').innerHTML = "*invalid";
		city_flag=1;
	    
	}
	else{
		document.getElementById('city_formerror').innerHTML = "";
		city_flag=0;

	}
}

function state_1()
{
	var state1= document.getElementById('states').value;
	
	if (state1.length < 5)
	{
		document.getElementById('state_formerror').innerHTML = "*invalid";
		s_flag=1;
	    
	}
	else{
		document.getElementById('state_formerror').innerHTML = "";
		s_flag=0;

	}
}



function zip()
{
    var zip=document.getElementById('Zip').value;
    var zipcheck= /^\d{5}([-]|\s*)?(\d{4})?$/;
	if (zipcheck.test(zip)){
        document.getElementById('zip_formerror').innerHTML = "";
		z_flag=0;
	}else{
        document.getElementById('zip_formerror').innerHTML = "*invalid";
		z_flag=1;
	}
	
}

function validateForm()
{
	var inputsa = document.getElementsByTagName('input');
     var c_radio=0;
       for(var x = 0; x < inputsa.length; x++) 
       {
         if(inputsa[x].type == 'radio') 
         {
           if(inputsa[x].checked)
		   {
			c_radio=1;
			break;
		   }
		 }

		}

		if(c_radio==0)
		{
			
		    radio_flag=1;
		}
		else
		{
			
		    radio_flag=0;
		}
	fname();
	lname();
	email();
	phonenumber();
	address();
	zip();
	
	city_1();
	state_1();

	var inputsax = document.getElementsByName('source');
	
	
	
     var cx_radio=0;
       for(var x = 0; x < inputsax.length; x++) 
       {
         if(inputsax[x].type == 'checkbox') 
         {
           if(inputsax[x].checked)
		   {
			cx_radio=1;
			break;
		   }
		   else{
			cx_radio=0;
		   }
		 }

		}

		if(cx_radio==0)
		{
			
		    source_flag=1;
		}
		else
		{
			
		    source_flag=0;
		}

	comment_1();

	
}


document.getElementById("submit").onclick=function()
{
	validateForm();
	var c;

	var inputs1= ["Tea_1","Coffee_1","Sand_1","Drink_1","Burger_1"];

	var inputs2= ["value_Tea","value_Coffee","value_Sand","value_Drink","value_Burger"];

	
	for(var i=0;i<inputs2.length;i++)
    {
		
		if(document.getElementById(inputs2[i]).style.display == "block")
		{

			c=document.getElementById(inputs1[i]).value;
			
			if (c=="")
			{
				
		        b_flag=1;
				break;
			}
		   else{
			b_flag=0;
		   }
			

		}

       
	}

	if( f_flag==1 ||  l_flag == 1 || e_flag ==1 || p_flag ==1 || a_flag ==1 || com_flag ==1 || city_flag ==1 ||s_flag==1 ||z_flag==1 ||radio_flag==1 ||source_flag==1 ||b_flag==1)
	{
		alert("One or more fields are invalid or Mandatory");
		return false;
		

	}
	else
	{
	
		var table = document.getElementById("myTable");
		var row = table.insertRow(-1);
	var fname = document.getElementById("firstName").value;
    var lname = document.getElementById("lastName").value;
	var email = document.getElementById('emailId').value;
	var phonenumber = document.getElementById('phoneNumber').value;
	
	var st1= document.getElementById('streetAddress1').value;
    var st2= document.getElementById('streetAddress2').value;
	var food=document.getElementById('mySelect').value;
	var zip=document.getElementById("Zip").value;
	var citya=document.getElementById("citys").value;
	var stateb=document.getElementById("states").value;
	var val;
	var inputsa = document.getElementsByTagName('input');
	
	  for(var x = 0; x < inputsa.length; x++) 
	  {
		if(inputsa[x].type == 'radio') 
		{
		  if(inputsa[x].checked)
		  {
		   val=inputsa[x].value;
		   break;
		  }
		}

	   }
     
	   var refer = [];
	   var d=0;
	   var inputsax =document.getElementsByName('source');;
	
       for(var x = 0; x < inputsax.length; x++) 
       {
		
         if(inputsax[x].type == 'checkbox') 
         {
           if(inputsax[x].checked)
		   {
			refer[d]=inputsax[x].value;
			d++;
			
		   }
		 }

		}
		console.log(refer);

		var cax= document.getElementById("comments").value;




	var cell1 = row.insertCell(0);
	var cell2 = row.insertCell(1);
	var cell3 = row.insertCell(2);
	var cell4 = row.insertCell(3);
	var cell5 = row.insertCell(4);
	var cell6 = row.insertCell(5);
	var cell7= row.insertCell(6);
	var cell8= row.insertCell(7);
	var cell9= row.insertCell(8);
	var cell10= row.insertCell(9);
	var cell11= row.insertCell(10);
	var cell12= row.insertCell(11);
	var cell13=row.insertCell(12);
	var cell14=row.insertCell(13);

	
	

	

	

    cell1.innerHTML=val;
	cell2.innerHTML= fname;
	cell3.innerHTML= lname;
	cell4.innerHTML= email;
	cell5.innerHTML=phonenumber;
	cell6.innerHTML=st1;
	cell7.innerHTML=st2;
	cell8.innerHTML=food;
	cell9.innerHTML=zip;
	cell10.innerHTML=citya;
	cell11.innerHTML=stateb;


	

	if(c!="")
			{
                
				cell12.innerHTML=c;
			}

			
			cell13.innerHTML=refer;
			cell14.innerHTML=cax;

	
	
	

	var inputs = ["value_Tea","value_Coffee","value_Sand","value_Drink","value_Burger"];
	var inputs1= ["Tea","Coffee","Sand","Drink","Burger"];
	
	
	for(var i=0;i<inputs.length;i++)
    {
		
		document.getElementById(inputs[i]).style.display="none";
		document.getElementById(inputs1[i]).style.display="none";

       
	}
	


	document.getElementById("formSubmission").reset();

	return false;
	}

	

}

function check(row)
{
	var c =row.value;
	
	if( row.checked == true)
    {
		document.getElementById(c).style.display="block";

    }
	else
	{
		document.getElementById(c).style.display="none";

	}
}

function wash()
{
	var inputs = ["value_Tea","value_Coffee","value_Sand","value_Drink","value_Burger"];
	
	for(var i=0;i<inputs.length;i++)
    {
		
		document.getElementById(inputs[i]).style.display="none";

       
	}
	var inputs = document.getElementsByTagName('input');
     
       for(var x = 0; x < inputs.length; x++) 
       {
         if(inputs[x].type == 'checkbox') 
         {
        inputs[x].checked=false;
		 }

		}
}




function myFunction() 
{
	wash();

	 var x = document.getElementById("mySelect").value;
	 var input = document.getElementsByTagName("option");
	  
	for(var i=0;i<input.length;i++)
	 {
		
		 if(input[i].value == x)
		 {
			
		   document.getElementById(input[i].value).style.display="block";
		 }
		 else
		 {
		   document.getElementById(input[i].value).style.display="none";
		   
		 }
	 }
	 
	
	}